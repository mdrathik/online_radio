
<div  class="agileinfo-header">
    <div class="container">
        <nav style="background-color:#043733" class="navbar navbar-default navbar-fixed-top">
            <div class="agile-logo">
                <div style="display: inline-flex"><h1><a href="./index.php"> &nbsp;<i class="fa fa-music  animated" aria-hidden="true"></i> Radio Title</a></h1>
                    <div  class="player">
                        <button  id="btnplay" style="margin: 5px;" class="pulse-button"><span  class="bounce bounceIn animated" aria-hidden="true"></span></button></h1>
                        <div class="songdetails">
                            <!--<h5 class="song title">In the End</h5>
                            <h6>Linkin Park</h6>
                            <h6>Album-Hit Album-2017</h6>-->
                        </div>

                    </div>

                    <!--	<div class="player">
                        <audio preload="" id="audio1" controls="controls" src="asset/http://radiotodaybd.fm/wp-content/uploads/music-topchart/3.Dhoa-Fuad-feat-Imran.mp3" autoplay>Your browser does not support HTML5 Audio!</audio>
                </div>-->
                </div>
            </div>
            <div >
            </div>

            <div  class="agileits-w3layouts-icons">
                <div class="">
                    <button class="navbutton btn btn-circle btn-success"><i class="fa fa-facebook"></i></button>
                    <button class="navbutton btn btn-circle btn-danger"><i class="fa fa-google-plus"></i></button>
                    <button class="navbutton btn btn-circle btn-primary"><i class="fa fa-twitter"></i></button>
                    <button class="navbutton btn btn-circle btn-danger"><i class="fa fa-youtube"></i></button>
                    <?php if (isset($_SESSION['username'])){ ?>
                    <a title="Logout" href="./model/member_logout.php" class="navbutton btn  btn-danger"><i class="fa fa-sign-out"></i>&nbsp;<?php echo $_SESSION['username'];  ?></a>
                    <?php }
                    else{ ?>
                        <a title="Login" href="./userlogin.php" class="navbutton btn  btn-warning"><i class="fa fa-sign-in"></i>&nbsp; Login</a>
                    <?php  }

                    ?>
                </div>

            </div>
            <div class="clearfix"> </div>
        </nav>
    </div>
</div>